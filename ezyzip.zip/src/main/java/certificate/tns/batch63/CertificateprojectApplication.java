package certificate.tns.batch63;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CertificateprojectApplication {

	public static void main(String[] args) {
		SpringApplication.run(CertificateprojectApplication.class, args);
	}

}
