package certificate.tns.batch63;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CertificateprojectApplicationTests {

	@Test
	void contextLoads() {
	}

}
